#        Ya...______..aab                #
#         Y88a  Y88o  Y88a   (     )     #
#          Y88b  Y88b  Y88b   `.  '      #
#          :888  :888  :888  ( (`-'      #    Generic declaration of functions
# .---.    d88P  d88P  d88P   `.`.       #
#/ .-._)  d8P'"""|"""'-Y8P      `.`.     #    NAvigation PAth GRAphichs
#( (`._) .-.  .-. |.-.  .-.  .-.   ) )   #
#\ `---( O )( O )( O )( O )( O )-' /     #
#`.    `-'  `-'  `-'  `-'  `-'  .'       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#




#~~~~~~~~~~~~~~~~~~~~~~~~~#
#    I.  Getters           #
 #   II.  napagra.describe  #
  #  III.  napagra.index     #
   #  IV.  napagra.paint      #
    #   V.  napagra.compute    #
     #   VI. napagra.neighboors #
      #  VII. napagra.distM      #
       #~~~~~~~~~~~~~~~~~~~~~~~~~~#




##I. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Getters
#


setGeneric("napagra.vertices", function (object) {standardGeneric("napagra.vertices")})
setGeneric("napagra.labels", function (object) {standardGeneric("napagra.labels")})
setGeneric("napagra.adjacency", function (object) {standardGeneric("napagra.adjacency")})


##II.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.describe
#


setGeneric("napagra.describe", function (object, index) {
      standardGeneric("napagra.describe")
    }
)


##III. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.index
#


setGeneric("napagra.index", function (object, string) {
    standardGeneric("napagra.index")
  }
)


##IV.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.paint
#


setGeneric("napagra.paint", function (object, x_special = NULL, xlim = NULL, ylim = NULL, xlab = "", ylab = "",
                                      cex_special = 1, x_unique = NULL,
                                      first = NULL, last = NULL, col.lattice = "grey72", col.vertices = "grey60", 
                                      col.special = "dodgerblue", col.unique =  "darkgoldenrod", 
                                      save = FALSE, path = NULL, main = NULL) {
    standardGeneric("napagra.paint")
  }
)


##V. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.compute
#


setGeneric("napagra.compute", function (object, x, y, p) {
    standardGeneric("napagra.compute")
  }
)


##VI.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.neighboors
#


setGeneric("napagra.neighboors", function (object, x, dist = 1, direction = FALSE) {
    standardGeneric("napagra.neighboors")
  }
)


##VII. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.distM
#


setGeneric("napagra.distM", function (object, x, y) {
    standardGeneric("napagra.distM")
  }
)

