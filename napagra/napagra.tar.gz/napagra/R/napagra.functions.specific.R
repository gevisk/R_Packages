#        Ya...______..aab                #
#         Y88a  Y88o  Y88a   (     )     #
#          Y88b  Y88b  Y88b   `.  '      #
#          :888  :888  :888  ( (`-'      #    Specific declaration of  functions
# .---.    d88P  d88P  d88P   `.`.       #
#/ .-._)  d8P'"""|"""'-Y8P      `.`.     #    NAvigation PAth GRAphichs
#( (`._) .-.  .-. |.-.  .-.  .-.   ) )   #
#\ `---( O )( O )( O )( O )( O )-' /     #
#`.    `-'  `-'  `-'  `-'  `-'  .'       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#




#~~~~~~~~~~~~~~~~~~~~~~~~~#
#    I.  Getters           #
 #   II.  napagra.describe  #
  #  III.  napagra.index     #
   #  IV.  napagra.paint      #
    #   V.  napagra.compute    #
     #   VI. napagra.neighboors #
      #  VII. napagra.distM      #
       #~~~~~~~~~~~~~~~~~~~~~~~~~~#




##I. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Getters
#


setMethod (f = "napagra.vertices", signature = "Napagra",
           function (object) {return (object@vertex)}
)
setMethod (f = "napagra.labels", signature = "Napagra",
           function (object) {return (object@labels)}
)
setMethod (f = "napagra.adjacency", signature = "Napagra",
           function (object) {return (object@adjacency)}
)

##II.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.describe
#


setMethod (f = "napagra.describe", signature = "Napagra",
           function (object, index) {
             return (object@labels[index])
           }
)


##III. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.index
#


setMethod (f = "napagra.index", signature = "Napagra",
           function (object, string) {
             return (which(object@description == string))
           }
)


##IV.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.paint
#

setMethod (f = "napagra.paint", signature = "Napagra",
           function(object, x_special = NULL, xlim = NULL, ylim = NULL, xlab = "", ylab = "",
                                     cex_special = 1, x_unique = NULL,
                                     first = NULL, last = NULL, col.lattice = "grey72", col.vertices = "grey60",
                                     col.special = "dodgerblue", col.unique =  "darkgoldenrod",
                                     save = FALSE, path = NULL, main = NULL) {

               compute.x.y =  function(object) {
                 x = 1:ncol(object@adjacency)
                 y=c()
                 for (i in 1:length(x)) { y[i] = sum(object@vertex[i,]) }
                 ytemp = -1
                 for (i in 1:length(x)){
                   if (ytemp == y[i]){ k = k +1 }
                   else { k = 1 }
                   x [i] = k / (length(which(y == y[i])) + 1)
                   ytemp = y[i]
                 }
                 x = scale(x,center = TRUE,scale = FALSE)
                 return(cbind(x,y))
               }

               compute.path = function(path = NULL, file = NULL, first = "min", last = "max"){
                 if (is.null(path)){
                   path = getwd()
                 }
                 if (is.null(file)){
                   file = paste("lattice",first,last,sep = "_")
                 }
                 if (substr(path,nchar(path),nchar(path))!="/"){
                   path = paste(path,"/",file,".jpg",sep = "")
                 }else{
                   path = paste(path,file,".jpg",sep = "")
                 }
                 return(path)
               }

               compute.plot = function (object,x,y,xlab,ylab,xlim,ylim,main,first,last,col.lattice,col.vertices,
                                        x_s, y_s, cex_special, col.special, x_unique, y_uni, cex.uni, col.unique,
                                        index_uni, index_special){
                 if (is.null(xlim)) xlim = c(min(x)-0.1,max(x)+0.1)
                 if (is.null(ylim)) ylim = c(first-1,last+1)

                 plot(NULL,NULL, cex = 0.5, pch = 19, axes = FALSE, xlab = xlab, ylab = ylab,
                      xlim = xlim, ylim = ylim, main = main)

                 for (i in 1:(length(x)-1)){
                   neighboors = napagra.neighboors(object,i,direction = TRUE)
                   neighboors = neighboors[neighboors>0]
                   if (y[i]>=first & y[i]<=last){
                     if (y[max (neighboors)]>=first & y[min (neighboors)]<=last) {
                       for (j in 1:length(neighboors)){
                         if (y[neighboors[j]]>=first & y[neighboors[j]]<= last){
                           segments(x0 = x[i], y0 = y[i], x1 = x[neighboors[j]], y = y[neighboors[j]], col = col.lattice, lwd = 1)
                         }
                       }
                     }
                     points(x[i],y[i], col = col.vertices, cex = 0.8, pch = 19)
                   }
                 }

                 if(length(x_unique)>0){
                     for (i in 1:length(x_s)){
                       points(x_unique,y_uni, col = col.unique, cex = cex.uni, pch = 19)
                       text(x_unique-0.05,y_uni+0.5, labels=object@labels[index_uni], cex = 1, col = "darkgoldenrod4")
                     }
                    if (length(x_s)>0){
                     for (i in 1:length(x_s)){
                       points(x_s[i],y_s[i], col = col.special, cex = cex_special[i]*40+1, pch = 19)
                       segments(x0 = x_s[i], y0 = y_s[i], x1 = x_unique, y = y_uni ,col = col.special, lwd = 2)
                       text(x_s[i]-0.05,y_s[i]+cex_special[i]*10,labels=object@labels[index_special[i]],
                            cex = 1, col = "darkblue")
                     }
                   }
                 }

               }
              #Execution


               X = compute.x.y(object)
               if (is.null(first)){first = 1}
               if (is.null(last)){last = nrow(X)}

               first = X[first,2]
               last = X[last,2]

               if (save) {
                 path = compute.path(path,main,first,last)
                 jpeg(path,width = 1600, height = 900)
               }

               compute.plot(object,X[,1],X[,2],xlab,ylab,xlim,ylim,main,first,last,col.lattice,col.vertices,
                            x_s = X[x_special,1], y_s = X[x_special,2], cex_special = cex_special, col.special = col.special,
                            x_unique = X[x_unique,1], y_uni = X[x_unique,2], cex.uni = 2, col.unique = col.unique, index_uni = x_unique,
                            index_special = x_special)


               if (save) {
                 dev.off()
               }
             }
)



##V. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.compute
#





##VI.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.neighboors
#


setMethod(f = "napagra.neighboors", signature = "Napagra",
          function (object, x, dist = 1, direction = FALSE) {
            neighboors = c()
            if (dist >= 1){
              for (j in 1:ncol(object@adjacency)){
                if (object@adjacency[x,j] == 1){
                  if (direction){
                    if (j < x) {neighboors = c(neighboors, - j)
                    } else{
                      neighboors = c(neighboors, j)
                  }}else{
                      neighboors = c(neighboors, j)
                  }
                }
              }
            }
            return(neighboors)
          }

)


##VII. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  napagra.distM
#

setMethod(f = "napagra.distM", signature = "Napagra",
          function (object, x, y) {
            distance = 0
            for (j in 1:ncol(object@vertex)){
              distance = distance + sqrt((object@vertex[x,j] - object@vertex[y,j])^2)
            }
            return(distance)
          }

)


