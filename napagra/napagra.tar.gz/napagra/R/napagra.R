#        Ya...______..aab                #
#         Y88a  Y88o  Y88a   (     )     #
#          Y88b  Y88b  Y88b   `.  '      #
#          :888  :888  :888  ( (`-'      #    Creation of a Lattice object
# .---.    d88P  d88P  d88P   `.`.       #
#/ .-._)  d8P'"""|"""'-Y8P      `.`.     #    NAvigation PAth GRAphichs
#( (`._) .-.  .-. |.-.  .-.  .-.   ) )   #
#\ `---( O )( O )( O )( O )( O )-' /     #
#`.    `-'  `-'  `-'  `-'  `-'  .'       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#




#~~~~~~~~~~~~~~~~~~~~~~#
#   I.  Description     #
 #  II.  Definition      #
  # III.  Validity        #
   #  IV.  Show/Print      #
    #~~~~~~~~~~~~~~~~~~~~~~~#




##I. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Description
#

  # Attributs
  # vertex
  #     list of all the vertices, defined by the indices of the subdimensions for each dimension. the vertices are sorted
  #     by their distance with the state
  # labels
  #     The vector of dimensions contains a list of all the vertex with their labels (dimensions associated)
  # adjacency
  #     the matrix adjacency_lattice contains the adjacency table of a lattency graph

  # Methods
  # setValidity
  #     check the validity of an object when its creation or modification
  # show
  #     this method is used by R to define what is print when the user type the name of a Napagra object (limit to 10 observations)
  # print
  #     nearly the same as show but here, the user specify he wants to display a Napagra object with print(Napagra)
  #     (no limit of observations)

  #The following methods are in the file napagra.constructor.R, all, but napagra.create() and bubbleSort, are privates functions as n
  #they only concer creation. lattice.dsitV is also written to function with a Napagra object in the next part
  # napagra.create
  #     Userfriendly constructor of a Napagra object (need a vector of dimensions)
  # bubbleSort
  #     ascending sort a data set by the sum of its lines
  # lattice.dimLattice (private)
  #     construc the attribut vertex
  # lattice.vertexDescriptor (private)
  #     construct the attribut labels
  # lattice.distM (private)
  #     compute the distance of Manhattan between two vertices
  # lattice.neighboor (private)
  #     return TRUE if two vertices i and j are neighboors (distance of Manhattan = 1), else return FALSE
  # lattice.adjacency (private)
  #     construct the attribut adjacency

  #The followings methods are in the files napagra.functions.generic.R and napagra.functions.specific.R
  # Getters
  # in the form of napagra.[attribut]() return attribut
  # napagra.describe
  #     give the labels (subdimensions) of a given vertex
  # napagra.index
  #     give the index corresponding to a given labels (subdimensions)
  # napagra.paint
  #     paint a plot (x <=> index of the vertex, y <=> distance with the reference vertex) see doc or function for more informations
  # napagra.compute (private)
  #     compute coordinates of vertices
  # napagra.neighboors
  #   return the neighboors of a given vertex
  # napagra.distM
  #   same as lattice.distM, compute the distance of Manhattan between two vertices




##II.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Definition
#

  setClass("Napagra",
           representation(
             vertex = "matrix",
             labels = "vector",
             adjacency = "matrix"
           )
  )
#constructor can be found in napagra.constructor.R and is nearly unavoidable in order to create a napagra


##III. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Check validity of an object:
#
#1: labels must be a vector of characters
#2: adjacency must be a squared matrix
#3: vertex, labels, and adjacency must have the same number of rows, as they concern the same number of vertex
setValidity("Napagra",
            function(object){
                if (!is.character(object@labels)){
                  return("the labels vector must contain only characters")
                }else{if (nrow(object@adjacency)!=ncol(object@adjacency)){
                  return("the matrix of adjacency must be a squared matrix")
                }else{if (!(nrow(object@vertex)==length(object@labels) & nrow(object@vertex) == nrow (object@adjacency))){
                  return("all the objects must have the same number of rows (= to the number of vertices)")
                }
            }}}
)


##IV.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Show/Print
#
#** show
setMethod(f = "show","Napagra",
          function (object) {
            granularity=lattice.distM(object@vertex,1,nrow(object@vertex))
            sub_dims = 0
            for (i in 1:ncol(object@vertex)){
              sub_dims=sub_dims+max(object@vertex[,i])
            }
            cat("    ____|*____  NAvigation PAth GRAphichs\n")  ;
            cat("   (         (   dimensions: "); print(ncol(object@vertex))
            cat("  (         (    subdimensions: "); print(sub_dims)
            cat("   (_________(   cuboides: "); print(nrow(object@vertex))
            cat(" _______||_____  edges: ") ; print(sum(object@adjacency))
            cat(" \\            | granularity: "); print(granularity)
            cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")

            nrowShow  <- min(10,nrow(object@vertex));
            cat("\nMatrix of adjacency (10 first vertices):\n");
            print(object@adjacency[1:nrowShow,1:nrowShow])
            cat("\nDescription of the 10 first vertices:\n")
            print(object@labels[1:nrowShow])
          }
)
#** print
setMethod(f = "print","Napagra",
          function (x,...) {
            granularity=lattice.distM(x@vertex,1,nrow(x@vertex))
            sub_dims = 0
            for (i in 1:ncol(x@vertex)){
              sub_dims=sub_dims+max(x@vertex[,i])
            }
            cat("NAvigation PAth GRAphichs\n")  ;
            cat("dimensions: ")    ; print(ncol(x@vertex))
            cat("subdimensions: ") ; print(sub_dims)
            cat("cuboides: ")      ; print(nrow(x@vertex))
            cat("edges: ")         ; print(sum(x@adjacency))
            cat("granularity: ")   ; print(granularity)

            cat("\nMatrix of adjacency:\n");
            print(x@adjacency)
            cat("\nDescription of the vertices:\n")
            print(x@labels)
          }
)
