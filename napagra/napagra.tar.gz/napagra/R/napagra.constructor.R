#        Ya...______..aab                #
#         Y88a  Y88o  Y88a   (     )     #
#          Y88b  Y88b  Y88b   `.  '      #
#          :888  :888  :888  ( (`-'      #    Constructor of a napagra object and privates methods associated
# .---.    d88P  d88P  d88P   `.`.       #
#/ .-._)  d8P'"""|"""'-Y8P      `.`.     #    NAvigation PAth GRAphichs
#( (`._) .-.  .-. |.-.  .-.  .-.   ) )   #
#\ `---( O )( O )( O )( O )( O )-' /     #
#`.    `-'  `-'  `-'  `-'  `-'  .'       #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#




#~~~~~~~~~~~~~~~~~~~~~#
#   I.  Vertex         #
 #  II.  Description    #
  # III.  Adjacency      #
   #  IV.  Constructor    #
    #~~~~~~~~~~~~~~~~~~~~~~#




##I. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Vertex: table referencing all vertices and their modalities for each dimension
#

#** private.bubble
#
#
lattice.bubbleSort = function(data){
  swap = c()
  for (i in nrow(data):2)
  {
    sort_test = TRUE
    j = 1
    while (j < i){
      if (sum(data[j+1,])<sum(data[j,])){
        sort_test=FALSE
        swap = data[j+1,]
        data[j+1,] = data[j,]
        data[j,] = swap
      }
      j=j+1
    }
    if (sort_test){
      return (data)
    }
  }
  return (data)
}

#** lattice.dimLattice
# IN :
#  * vec_dims : see constructor
# OUT:
#  * vertex : list of all the vertices, defined by the indices of the subdimensions for
#    each dimension. the vertices are sorted by their distance with the state 0 (ALL,...,ALL)
lattice.dimLattice = function(vec_dims){
    nb_dims=0
    nb_vertices=1
    ite_max=c()

    for(i in 1:length(vec_dims)){
        ite_max=c(ite_max,length(strsplit(vec_dims," ")[[i]]))
        nb_dims=nb_dims+ite_max[i]
        nb_vertices = nb_vertices*(ite_max[i] + 1)
    }
    vertex=matrix(0,nrow=nb_vertices,ncol=length(vec_dims))
    ite = rep(0,length(vec_dims))
    for (i in 1:nb_vertices){
        sum1 = 0
        sum2 = 0
        for (j in 1:length(vec_dims)){
          vertex[i,j]=ite[j]
          if (j==1 | (j>1 & sum1==sum2)){
            if (ite[j]<ite_max[j]){
              ite[j]=ite[j]+1
            }else{
              ite[j] = 0
            }
          }
          sum1 = sum1+vertex[i,j]
          sum2 = sum2+ite_max[j]
        }
    }
    vertex=lattice.bubbleSort(vertex)
    return(vertex)
}


##II.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  labels: for each vertex, give a string describing the modalities it have, separated by spaces
#


#** lattice.vertexDescriptor
# IN :
# * vec_dims: see constructor
# * vertex: list of all the vertices, defined by the indices of the subdimensions for
#    each dimension. the vertices are sorted by their distance with the state 0 (ALL,...,ALL)
# OUT:
# * labels: for each state index, give a string containing the subdimensions describing it separated ba a ' ' (a space)
lattice.vertexDescriptor = function(vec_dims,vertex) {
  labels = c(length = nrow(vertex))
    for (i in 1:nrow(vertex)){
      line = ""
      for (j in 1:ncol(vertex)){
        if (vertex[i,j]==0){
          line=paste(line,"all",sep = " ")
        }else{
          line=paste(line,strsplit(vec_dims," ")[[j]][vertex[i,j]],sep = " ")
        }
      }
      labels[i]=substr(line,2,nchar(line))
    }
    return (labels)
}


##III. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  adjacency: the matrix of adjacency of the lattice
#


#** lattice.distM
#IN :
# * vertex: list of all the vertices, defined by the indices of the subdimensions for
#    each dimension. the vertices are sorted by their distance with the state 0 (ALL,...,ALL)
# * i,j two vertex indices
#OUT :
# * distance: the distance of Manhattan between i and j
lattice.distM = function (vertex,i,j) {
  distance = 0
  for (k in 1:ncol(vertex)){
    distance = distance + sqrt((vertex[i,k] - vertex[j,k])^2)
  }
  return(distance)
}

#** lattice.neighboor
# IN :
#  * vertex: list of all the vertices, defined by the indices of the subdimensions for
#    each dimension. the vertices are sorted by their distance with the state 0 (ALL,...,ALL)
#  * i, j: two vertices
#	OUT:
#  * TRUE if i and j are neighboors in the graph
#  * FALSE if they are not
lattice.neighboor = function (vertex,i,j) {
    if (lattice.distM(vertex,i,j)==1){  # if distance between i and j = 1 :
      return(TRUE)  #they are neighboors
    } else{
      return(FALSE)# else they are not
    }
}

#** lattice.adjacency
# IN :
#  * vertex: list of all the vertices, defined by the indices of the subdimensions for
#    each dimension. the vertices are sorted by their distance with the state 0 (ALL,...,ALL)
#	OUT:
#  * adjacency : the matrix of adjacency of the lattice (0: no edge, 1: edge)
lattice.adjacency = function (vertex) {
  adjacency = matrix(0,nrow = nrow(vertex), ncol = nrow(vertex))
  for (i in 1:nrow(adjacency)){
    for (j in 1:ncol(adjacency)){
      if (lattice.neighboor(vertex,i,j)){
        adjacency[i,j]=1
      }
    }
  }
  return(adjacency)
}


##IV.  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#####
#
#  Constructor of the Napagra class:
#

#napagra.create
#IN:
#   * vec_dims is a vecteur of n values where n is the number of dimensions of the lattice
#     for each value write a string containing each of the subdimensions (whithout 'ALL') of the corresponding dimensions
#     subdimensions must be separated with spaces.
# example of vec_dims:
# vec_dims = c("days hours minutes","continent country region city","product_class product_subclass product_name","customer_type")
# vec_dims has in this examples 4 dimensions
#OUT
#   * an object of class napagra, see napagra.r for more details
#
napagra.create = function(vec_dims){
  if(!is.character(vec_dims)){
    return ("vec_dims must be a vector of Strings. See documentation ?napagra.create() for more details")
  }else{
    vertex = lattice.dimLattice(vec_dims)
    labels = lattice.vertexDescriptor(vec_dims,vertex)
    adjacency = lattice.adjacency(vertex)
    return (new ("Napagra",vertex = vertex, labels = labels, adjacency = adjacency))
  }
}

