###########                                                                                       ###########
 #  ###  #                                                                                         #  ###  #
 # #   # #                                                                                         # #   # #
 #  # #  #                                                                                         #  # #  #
 #   #   #                              Creation of the DMC class                                  #   #   #
 #  # #  #                                 Dynamic Markov Chain                                    #  # #  #
 # #   # #                                                                                         # #   # #
 #  ###  #  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #  #  ###  #
###########                                                                                       ###########




########################
#   I.  Description     #
 #  II.  Definition      #
  # III.  Validity        #
   #  IV.  Constructor     #
    #   V.  Show/Print      #
     ########################




##I. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Description
#

  # Attributs
    # states
        # This matrix of dimensions nb_states x 1 contains the probabilities of states
    # transitions
        # this matrix of dimensions nb_states x nb_states contains the probabilities of transitions such as :
        #         transitions[i ,j] is equal to the probability of transition from the state i to the state j
    # n
        # n is the total number of transitions (frequencies, not probabilities !)
    # current
        # current retain the index (integer) associate whith the state in which the system stands now

  # Methods
    # setValidity
        # check the validity of an object when its creation or modification
    # dmc.create
        # Userfriendly constructor of a DMC object, avoid a lot of steps(need a matrix or the number of states)
    # show
        # this method is used by R to define what is print when the user type the name of an DMC object
    # print
        # nearly the same as show but here, the user specify he wants to display a DMC object with print(DMC)

 #The followings methods are in the files dmc.functions.generic.R and dmc.functions.specific.R
    # dmc.update
        # update the matrix states and transitions by adding a new data in the model
    # dmc.napare
        # recommend one or more path to the user
    # dmc.x
        # allow the user to get an object x which is part of a DMC


##II.  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Definition
#

  setClass(Class = "DMC",
      representation(
        states = "matrix",
        transitions = "matrix",
        n = "integer",
        current = "integer"
      )
  )


##III. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Check validity of an object:
#

#1: the numbers of requests done must be equal or superior to 0
#2: the index of the current vertex must be equal or superior to 0 and inferior to the maximum of vertices
#3: the matrix of transitions must be squared (having the same number of rows and columns)
#4: the matrix of transitions must have the same number of rows than the matrix of states
#5: the matrix of state must have one column (only one probability per state)
#6,7: the probabilities must be between 0 and 1

  setValidity ("DMC",
      function (object){
        if (object@n<0){
          return ("the number of requests cannot be negative.");
        }else if (object@current < 0 | object@current > NCOL(object@transitions)){
          return ("the current vertex must be referenced with an integer referencing a vertex.");
        }else if (ncol(object@transitions) != nrow(object@transitions)){
          return ("the matrix of transitions must be a squared matrix.");
        }else if (nrow(object@states) != nrow(object@transitions)){
          return ("the number of states must be the same in the transitions matrix and the states matrix (same number of rows)");
        }else if (ncol(object@states)>1){
          return ("there must be only one column for the matrix of states, as there is only one probability per state")
        }else if (min(object@states)<0 | max(object@states)>1){
          return ("the probabilities of states must be in the interval [0,1]");
        }else if (min(object@transitions)<0 | max(object@transitions)>1){
          return ("the probabilities of transition must be in the interval [0,1]");
        }else
          return (TRUE);
      }
  )


##IV.  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Constructor of the DMC class:
#

#IN
#data
  dmc.create = function (data,current = 1) {
          #If the data parameter is a matrix of adjacency
          if (is.matrix(data)){
              transitions = matrix(nrow = nrow(data), ncol = ncol(data));#declaration of transitions
              states = matrix(nrow = nrow(data), ncol = 1);              #declaration of states
              n=sum(data);                                               #compute n as sum of all datas (frequencies)
              #estimate the probabilities of state and transition
              for (i in 1:nrow(data)){
                  states[i,1]=sum(data[i,])/n;  #compute states for the line i
                  for (j in 1: ncol(data)){     #for each j, compute Pt(i->j)
                      if (states[i]!=0) transitions[i,j]= data[i,j]/(states[i,1]*n);
                  }
              }         #if  data is a number (decimal) but with only a integer part we consider it like an integer
          }else if (is.integer(data) | (is.numeric(data) & (data-as.integer(data)) == 0)){
              #If there is no matrix of frequencies, attribute the same default probability to all transitions
              transitions = matrix(0,nrow = data, ncol = data);
              #Same for states
              states = matrix (0,nrow = data, ncol = 1);
              n=0;
          }else{
            #the parameter as a wrong type
            return (paste("ERROR: the parameter data must be the matrix of adjacency of the frequencies of transition
                                or if appropriate, the number of vertices (integer)"));
          }
          return (new ("DMC",
                states = states,
                transitions = transitions,
                n = as.integer(n),
                current = as.integer(current)
              )
          )
  }


##V.   # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Show/Print:
#

#Show
setMethod(f = "show", signature = "DMC",
            function(object){
              cat("******  Dynamic Markov Chain \n"); 
              cat(" *  *   datas: ");print(object@current);
              cat("  **    Current state: ");print(object@n);
              cat(" *  *   states: ");print(ncol(object@transitions));
              cat("******  transitions: ");print(ncol(object@transitions)*ncol(object@transitions));

              nrowShow  <- min(10,nrow(object@transitions));
              cat("\nTable of probabilities of state (10 first states):\n");
              print(object@states[1:nrowShow,])
              cat("\nTable of probabilities of transition (10 first states):\n")
              print(object@transitions[1:nrowShow,1:nrowShow])
            }
         )
#Print
  setMethod(f = "print", signature = "DMC",
            function(x,...){
              cat("Dynamic Markov Chain \n");
              cat("Current state: ");print(x@current);
              cat("Number of datas: ");print(x@n);
              cat("Number of states: ");print(ncol(x@transitions));
              cat("Number of transitions: ");print(ncol(x@transitions)*ncol(x@transitions));
              #nrowShow  <- min(10,nrow(x@transitions));
              cat("\nTable of probabilities of state:\n");
              print(x@states)
              cat("\nTable of probabilities of transition:\n")
              print(x@transitions)
            }
  )

