###########                                                                                       ###########
 #  ###  #                                                                                         #  ###  #
 # #   # #                                                                                         # #   # #
 #  # #  #                                                                                         #  # #  #
 #   #   #                          Specific declaration of functions                              #   #   #
 #  # #  #                                 Dynamic Markov Chain                                    #  # #  #
 # #   # #                                                                                         # #   # #
 #  ###  #  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #  #  ###  #
###########                                                                                       ###########




########################
#   I.  Getters         #
 #  II.  Update          #
  # III.  Pathfinder      #
   #  IV.  Others          #
    ########################




##I. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Getters
#
setMethod(f = "dmc.states", signature = "DMC",
    function(object){
        return (object@states)
    }
)
setMethod(f = "dmc.transitions", signature = "DMC",
    function(object){
      return (object@transitions)
    }
)
setMethod(f = "dmc.n", signature = "DMC",
    function(object){
      return (object@n)
    }
)
setMethod(f = "dmc.current", signature = "DMC",
    function(object){
      return (object@current)
    }
)

##II.  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Update
#
setMethod(f = "dmc.update", signature = "DMC",
          function(object,x){
            if (object@current!=as.integer(x)){
              #frequency of the current state
              n_current = object@n * object@states[object@current]
              #P(current,x)
              object@transitions[object@current,x] = (n_current * object@transitions[object@current,x] + 1) / (n_current + 1)
              #P(current,i)
              for (i in (1:ncol(object@transitions))[c(-x,-object@current)]){ #for i, any state different of x or current state
                object@transitions[object@current,i] = (n_current * object@transitions[object@current,i]) / (n_current + 1)
              }
              #P(current)
              object@states[object@current] = (n_current + 1) / (object@n + 1)
              #P(i)
              for (i in (1:nrow(object@states))[c(-object@current)]){ #for i, any state different of x or current state
                n_i = object@n * object@states[i]#frequency of the i state
                object@states[i] = (n_i) / (object@n + 1)
              }
              #n
              object@n = as.integer(object@n + 1)
              #current
              object@current = as.integer(x)

              return(object)
            }else{
              return(object)
            }
          }
)


##III. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Pathfinder
#


setMethod(f = "dmc.napare", signature = "DMC",
  function(object, state=NULL, threshold = 0.05, rec_size = 1){
    if(is.null(state)){state=object@current}
    path_vector = c()
    #transtition_path receive transitions probabilities (needed because we will modificate them)
    transition_path = object@transitions[state,]
    k = 0 #count the number of recommandations
    while(k<rec_size){
      maximum = c(which.max(transition_path),max(transition_path))
      if (maximum[2]>threshold){
        path_vector=rbind(path_vector,maximum)
        transition_path[maximum[1]]=-2   #to avoid repetitions
        k=k+1
      }else{
        return (path_vector)
      }
    }
    return (path_vector)
  }
)


##IV.  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Others
#
#Modify current state
setMethod(f = "dmc.current.set", signature = "DMC",
    function (object, x){
      object@current=as.integer(x)
      return(object)
    }
)

setMethod(f = "dmc.gen.data", signature = "DMC",
    function (object, x){
      while (object@n<x){

        object=dmc.update(object,sample(1:nrow(object@states), 1))
      }
      return (object)
    }
)




