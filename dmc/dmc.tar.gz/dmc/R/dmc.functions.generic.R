###########                                                                                       ###########
 #  ###  #                                                                                         #  ###  #
 # #   # #                                                                                         # #   # #
 #  # #  #                                                                                         #  # #  #
 #   #   #                      Generic declaration of functions for DMC                           #   #   #
 #  # #  #                                 Dynamic Markov Chain                                    #  # #  #
 # #   # #                                                                                         # #   # #
 #  ###  #  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #  #  ###  #
###########                                                                                       ###########




########################
#   I.  Getters         #
 #  II.  Update          #
  # III.  PathFinder      #
   #  IV.  Others          #
    ########################




##I. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Getters
#
setGeneric("dmc.states", function (object) {standardGeneric("dmc.states")})
setGeneric("dmc.transitions", function (object) {standardGeneric("dmc.transitions")})
setGeneric("dmc.n", function (object) {standardGeneric("dmc.n")})
setGeneric("dmc.current", function (object) {standardGeneric("dmc.current")})


##II.  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Update
#
setGeneric("dmc.update",function (object,x) {
                standardGeneric("dmc.update")
            }
)


##III. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Pathfinder
#
setGeneric("dmc.napare",function (object, state=NULL, threshold = 0.05, rec_size = 1) {
                standardGeneric("dmc.napare")
            }
)

##IV.  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #####
#
#  Others:
#
#Modify current state
setGeneric("dmc.current.set",function (object, x){
                standardGeneric("dmc.current.set")
           }
)

#Generate random datas
setGeneric("dmc.gen.data",function (object, x){
                standardGeneric("dmc.gen.data")
          }
)
